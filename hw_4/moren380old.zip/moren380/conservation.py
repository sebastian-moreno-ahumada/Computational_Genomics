import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#extract sequences from fna files and store/return in a list
def read_fna_sequences(file_path):
    sequences = []
    with open(file_path, 'r') as file:
        for line in file:
            # Strip the newline character at the end of each line
            line = line.strip()
            # Check if line does not start with '>'
            if not line.startswith('>'):
                sequences.append(line)
    return sequences

#Calculate conservation rates at each position of sequences
def calculate_conservation(sequences):
    alignment_length = len(sequences[0])
    conservation_rates = []

    for i in range(alignment_length):
        base_counts = {}
        for seq in sequences:
            base = seq[i]
            if base in base_counts:
                base_counts[base] += 1
            else:
                base_counts[base] = 1

        # Find the maximum count out of the bases, except '-'
        max_count = -1
        for base in base_counts.keys():
            if base_counts[base] > max_count and base != '-':
                max_count = base_counts[base]
        conservation_rate = max_count/ len(sequences)
        conservation_rates.append(conservation_rate)
    #return conservation_rates

    df = pd.DataFrame(conservation_rates, columns=['rate'])
    # The Rolling window average of 80 was choosen in order to base smoothing over the previous 80 genes positions out of about 1500
    # approximately 5% dependency on previous values for current value smoothing   
    df['window_rates'] = df['rate'].rolling(window=80).mean()
    conservation_rates_window = df['window_rates'].tolist()
    #Question 3 plotting
    #df.plot(y=['window_rates'], kind='line', figsize=(16,12))
    #plt.title("Conservation Plot")
    #plt.xlabel("Position in 16S RNA gene")
    #plt.ylabel("Pct Conserved")
    #plt.show()
    return conservation_rates_window, df

#Find variable regions and also threshold for considering a variable region
def variable_regions(data, step_size):
    # Decided to use the average of all smoothed conservation percentages as the threshold point
    #    A differing statistic could be applied here easily but I just thought that the average reflected well 
    #    to the number of variability regions I could depict by eye. Moreover it gives 8 variable regions, only differs by one for the number 
    #    of widely accepted amount of 9.  
    variability_threshold = np.nanmean(data)
    #print("Variability threshold:", variability_threshold)

    variable_regions = []
    in_region = False
    start = None

    for i in range(0, len(data), step_size):
        # Disregard initial nan values
        if np.isnan(data[i]):
            continue

        if data[i] < variability_threshold and not in_region:
            # Start of a new variable region
            start = i
            in_region = True
        elif data[i] >= variability_threshold and in_region:
            # End of the current variable region
            end = i
            variable_regions.append((start, end))
            in_region = False

    # Check if the last region extends to the end of the list
    if in_region:
        variable_regions.append((start, len(data)))

    return variability_threshold, variable_regions

#Write conservations to an output to a file
def conservations_to_file(conservation_rates, outfile):
    with open(outfile, 'w') as file:
        pos = 1
        for rate in conservation_rates:
            file.write(f'Position {pos}: \t{rate}\n')
            pos+=1

#Write variable regions to an output to a file, tab spaced
def write_variable_regions_to_file(variable_regions, filename):
    with open(filename, 'w') as file:
        for start, end in variable_regions:
            # While I understand the ouptut was supposed to be tab delimited, the output looked less readable than
                # when I used 3 spaces... just a readability choice
            out_string = str(start) + "    " + str(end) + "\n"
            file.write(out_string)

if __name__ == "__main__":
    INPUT_FILE = 'Homework4-seqs-with-primers.fna'
    OUTPUT_FILE = 'solution-problem-1.txt'
    OUTPUT_FILE3 = 'solution-problem-3.txt'
    sequences = read_fna_sequences(INPUT_FILE)
    #conservation = calculate_conservation(sequences)
    conservation, df = calculate_conservation(sequences)
    #conservations_to_file(conservation, OUTPUT_FILE)
                        #List of conservation values, step size     
    threshold, regions = variable_regions(conservation, 10)
    #print(regions)
    write_variable_regions_to_file(regions, OUTPUT_FILE3)

    #Question 4 plotting
    #df.plot(y=['window_rates'], kind='line', figsize=(16,12))
    #plt.title("Conservation Plot")
    #plt.xlabel("Position in 16S RNA gene")
    #plt.ylabel("Pct Conserved")
    
    #add the threshold as a dashed line 
    #first = True
    #for start, end in regions:
    #    if first:
    #        plt.hlines(y=threshold, xmin=start, xmax=end, colors='r', linewidth=2, label="Variable region threshold")
    #        first = False
    #    else:
    #        plt.hlines(y=threshold, xmin=start, xmax=end, colors='r', linewidth=2)
    #plt.axhline(y=threshold, color='r', linestyle='--', label='Variable region threshold')
    
    #plt.legend()
    #plt.show()
